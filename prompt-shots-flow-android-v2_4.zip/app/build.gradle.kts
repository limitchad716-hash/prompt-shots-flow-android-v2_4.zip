plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.promptshots.flow"
    compileSdk = 34
    defaultConfig {
        applicationId = "com.promptshots.flow"
        minSdk = 24
        targetSdk = 34
        versionCode = 5
        versionName = "2.4.0"
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}
