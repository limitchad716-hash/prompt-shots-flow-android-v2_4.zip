package com.promptshots.flow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.Typeface
import android.view.View
import android.view.animation.LinearInterpolator
import kotlin.math.min

/**
 * The floating bubble: dark disc, gold "F" logo, rotating rainbow ring with a strong glow,
 * and a progress arc that fills from 0 to 100 % while Flow is generating.
 * The view is bigger than the disc so the glow has room to fade out.
 */
class GlowBubble(c: Context) : View(c) {
    /** Empty = draw the F logo. Anything else (countdown, REC) is drawn as text. */
    var label: String = ""
        set(v) { if (field != v) { field = v; invalidate() } }
    var fill: Int = 0xFF0B0D14.toInt()
        set(v) { if (field != v) { field = v; invalidate() } }
    var textColor: Int = Ui.TEXT
        set(v) { if (field != v) { field = v; invalidate() } }
    var textSp: Float = 16f
        set(v) { if (field != v) { field = v; invalidate() } }
    /** 0..1. 0 hides the arc. */
    var progress: Float = 0f
        set(v) {
            val n = v.coerceIn(0f, 1f)
            if (field != n) { field = n; invalidate() }
        }
    var glow: Boolean = true
        set(v) {
            field = v
            if (isAttachedToWindow) { if (v && animated) startSpin() else stopSpin() }
            invalidate()
        }
    /** False = the glow stays on but stops rotating (saves GPU while Run all is working). */
    var animated: Boolean = true
        set(v) {
            field = v
            if (isAttachedToWindow) { if (v && glow) startSpin() else stopSpin() }
            invalidate()
        }

    private val pad = Ui.dp(c, 18).toFloat()
    private val ringPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = Ui.dp(c, 3).toFloat()
    }
    private val glowPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val glowExtra = floatArrayOf(Ui.dp(c, 4).toFloat(), Ui.dp(c, 10).toFloat(), Ui.dp(c, 17).toFloat(), Ui.dp(c, 25).toFloat(), Ui.dp(c, 33).toFloat())
    private val glowAlphas = intArrayOf(170, 120, 78, 44, 20)
    private val fillPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val arcPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = Ui.dp(c, 3).toFloat(); strokeCap = Paint.Cap.ROUND; color = Ui.OK
    }
    private val logoPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        typeface = Typeface.DEFAULT_BOLD; textAlign = Paint.Align.CENTER
    }
    private val arcRect = RectF()
    private var logo = Path()
    private var angle = 0f
    private var spin: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val sg = SweepGradient(w / 2f, h / 2f, Ui.RAINBOW, null)
        ringPaint.shader = sg
        glowPaint.shader = sg
        val r = min(w, h) / 2f - pad
        logo = LogoMark.path(w / 2f, h / 2f, r * 1.15f)
        logoPaint.shader = LogoMark.goldShader(h / 2f - r * 0.58f, h / 2f + r * 0.58f)
    }

    override fun onAttachedToWindow() {
        super.onAttachedToWindow()
        if (glow && animated) startSpin()
    }

    override fun onDetachedFromWindow() {
        stopSpin()
        super.onDetachedFromWindow()
    }

    private fun startSpin() {
        if (spin != null) return
        spin = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 3500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    private fun stopSpin() {
        spin?.cancel()
        spin = null
    }

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f - pad
        val rs = ringPaint.strokeWidth
        if (glow) {
            canvas.save()
            canvas.rotate(angle, cx, cy)
            for (i in glowExtra.indices) {
                glowPaint.strokeWidth = rs + glowExtra[i]
                glowPaint.alpha = glowAlphas[i]
                canvas.drawCircle(cx, cy, r, glowPaint)
            }
            canvas.restore()
        }
        fillPaint.color = fill
        canvas.drawCircle(cx, cy, r, fillPaint)
        canvas.save()
        canvas.rotate(if (glow) angle else 0f, cx, cy)
        canvas.drawCircle(cx, cy, r - rs / 2f, ringPaint)
        canvas.restore()

        if (progress > 0f) {
            val ar = r - rs * 2.3f
            arcRect.set(cx - ar, cy - ar, cx + ar, cy + ar)
            canvas.drawArc(arcRect, -90f, 360f * progress, false, arcPaint)
        }

        if (label.isEmpty()) {
            canvas.drawPath(logo, logoPaint)
        } else {
            textPaint.color = textColor
            textPaint.textSize = textSp * resources.displayMetrics.scaledDensity
            val fm = textPaint.fontMetrics
            canvas.drawText(label, cx, cy - (fm.ascent + fm.descent) / 2f, textPaint)
        }
    }
}
