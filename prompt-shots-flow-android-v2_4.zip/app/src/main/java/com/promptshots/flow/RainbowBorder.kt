package com.promptshots.flow

import android.animation.ValueAnimator
import android.graphics.Canvas
import android.graphics.ColorFilter
import android.graphics.Matrix
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Rect
import android.graphics.RectF
import android.graphics.SweepGradient
import android.graphics.drawable.Drawable
import android.view.animation.LinearInterpolator

/**
 * Panel background: dark fill, a rotating rainbow ring, and a strong rainbow glow that spills
 * [glowPad] px outside the ring (the panel keeps that much transparent padding for it).
 * Only the shader matrix changes per frame, so it follows the screen's refresh rate smoothly.
 */
class RainbowBorder(
    private val radius: Float,
    private val stroke: Float,
    fillColor: Int,
    private val glowPad: Float
) : Drawable() {
    var glowOn: Boolean = true
        set(v) { field = v; invalidateSelf() }

    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = fillColor }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = stroke }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val rect = RectF()
    private val matrix = Matrix()
    private var shader: SweepGradient? = null
    private var angle = 0f
    private var anim: ValueAnimator? = null

    // Wide faint strokes stacked on top of each other = a soft, bright glow without a blur filter.
    private val haloExtra = floatArrayOf(3f, 8f, 14f, 21f, 28f)
    private val haloAlpha = intArrayOf(170, 120, 78, 44, 20)

    fun start() {
        if (anim != null) return
        anim = ValueAnimator.ofFloat(0f, 360f).apply {
            duration = 4500
            repeatCount = ValueAnimator.INFINITE
            interpolator = LinearInterpolator()
            addUpdateListener { angle = it.animatedValue as Float; invalidateSelf() }
            start()
        }
    }

    fun stop() {
        anim?.cancel()
        anim = null
    }

    override fun onBoundsChange(b: Rect) {
        shader = SweepGradient(b.exactCenterX(), b.exactCenterY(), Ui.RAINBOW, null)
        ring.shader = shader
        halo.shader = shader
    }

    override fun draw(canvas: Canvas) {
        val sh = shader ?: return
        matrix.setRotate(angle, bounds.exactCenterX(), bounds.exactCenterY())
        sh.setLocalMatrix(matrix)
        ring.shader = sh
        halo.shader = sh

        rect.set(bounds)
        rect.inset(glowPad, glowPad)
        val half = stroke / 2f
        if (glowOn) {
            for (i in haloExtra.indices) {
                halo.strokeWidth = stroke + haloExtra[i]
                halo.alpha = haloAlpha[i]
                canvas.drawRoundRect(rect, radius, radius, halo)
            }
        }
        canvas.drawRoundRect(rect, radius, radius, fill)
        rect.inset(half, half)
        canvas.drawRoundRect(rect, radius - half, radius - half, ring)
    }

    override fun setAlpha(alpha: Int) { fill.alpha = alpha; ring.alpha = alpha; invalidateSelf() }
    override fun setColorFilter(cf: ColorFilter?) { fill.colorFilter = cf; ring.colorFilter = cf }
    @Deprecated("Deprecated in Java")
    override fun getOpacity() = PixelFormat.TRANSLUCENT
}
