package com.promptshots.flow

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper

/** Posts the "automation finished" notification and plays the user's custom sound, if one is saved. */
object Notifier {
    private const val CH_DEFAULT = "flow_done"
    private const val CH_CUSTOM = "flow_done_custom" // silent channel; we play the saved sound ourselves
    private const val MAX_PLAY_MS = 15_000L
    private val h = Handler(Looper.getMainLooper())
    private var player: MediaPlayer? = null

    fun done(c: Context, title: String, text: String) {
        val ctx = c.applicationContext
        val nm = ctx.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        val custom = Prefs.hasCustomSound(ctx)
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CH_DEFAULT, "Automation finished", NotificationManager.IMPORTANCE_HIGH)
            )
            nm.createNotificationChannel(
                NotificationChannel(CH_CUSTOM, "Automation finished (custom sound)", NotificationManager.IMPORTANCE_HIGH)
                    .apply { setSound(null, null) }
            )
        }
        val open = PendingIntent.getActivity(ctx, 2, Intent(ctx, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        @Suppress("DEPRECATION")
        val b = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(ctx, if (custom) CH_CUSTOM else CH_DEFAULT)
        else Notification.Builder(ctx).setPriority(Notification.PRIORITY_HIGH)
            .apply { if (!custom) setDefaults(Notification.DEFAULT_SOUND) }
        b.setContentTitle(title)
            .setContentText(text)
            .setSmallIcon(R.drawable.ic_stat)
            .setContentIntent(open)
            .setAutoCancel(true)
        try { nm.notify(20, b.build()) } catch (_: Exception) {}
        if (custom) play(ctx, Uri.fromFile(Prefs.soundFile(ctx)))
    }

    /** Plays a sound (also used for the preview in Settings). Stops after 15 s so long files don't run on. */
    fun play(c: Context, uri: Uri) {
        stop()
        try {
            val mp = MediaPlayer()
            mp.setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_NOTIFICATION)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                    .build()
            )
            mp.setDataSource(c.applicationContext, uri)
            mp.setOnCompletionListener { stop() }
            mp.setOnErrorListener { _, _, _ -> stop(); true }
            mp.prepare()
            mp.start()
            player = mp
            h.postDelayed({ stop() }, MAX_PLAY_MS)
        } catch (_: Exception) { stop() }
    }

    fun stop() {
        h.removeCallbacksAndMessages(null)
        player?.let { try { it.stop() } catch (_: Exception) {}; try { it.release() } catch (_: Exception) {} }
        player = null
    }
}
