package com.promptshots.flow

import android.animation.ValueAnimator
import android.content.Context
import android.graphics.Canvas
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.os.SystemClock
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

/** The "F" logo: one polygon, used by the bubble, the headers and the app icon. */
object LogoMark {
    private val pts = floatArrayOf(
        22f, 86f, 22f, 14f, 84f, 14f, 78f, 32f, 42f, 32f,
        42f, 46f, 70f, 46f, 65f, 62f, 42f, 62f, 42f, 86f
    )

    /** F centred on (cx, cy), about [size] px tall. */
    fun path(cx: Float, cy: Float, size: Float): Path {
        val s = size / 100f
        val ox = cx - 53f * s
        val oy = cy - 50f * s
        val p = Path()
        var i = 0
        while (i < pts.size) {
            val x = ox + pts[i] * s
            val y = oy + pts[i + 1] * s
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            i += 2
        }
        p.close()
        return p
    }

    fun goldShader(top: Float, bottom: Float): Shader =
        LinearGradient(0f, top, 0f, bottom, intArrayOf(0xFFFFE38A.toInt(), 0xFFC98A1B.toInt()), null, Shader.TileMode.CLAMP)
}

/** Gold F with a soft gold glow behind it. */
class LogoView(c: Context) : View(c) {
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val halo = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeJoin = Paint.Join.ROUND; color = Ui.ACCENT
    }
    private var path = Path()

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val s = minOf(w, h) * 0.62f
        path = LogoMark.path(w / 2f, h / 2f, s)
        fill.shader = LogoMark.goldShader(h / 2f - s / 2f, h / 2f + s / 2f)
    }

    override fun onDraw(canvas: Canvas) {
        val widths = floatArrayOf(5f, 3.4f, 2f, 1f)
        val alphas = intArrayOf(18, 34, 60, 100)
        for (i in widths.indices) {
            halo.alpha = alphas[i]
            halo.strokeWidth = Ui.dp(context, 1) * widths[i] * 2.4f
            canvas.drawPath(path, halo)
        }
        canvas.drawPath(path, fill)
    }
}

/** ScrollView that never grows taller than [maxH] (the floating panel scrolls instead of leaving the screen). */
class MaxHeightScrollView(c: Context, private val maxH: Int) : ScrollView(c) {
    override fun onMeasure(w: Int, h: Int) {
        super.onMeasure(w, MeasureSpec.makeMeasureSpec(maxH, MeasureSpec.AT_MOST))
    }
}

/** Text button with a gold / glass / danger look, a smooth press animation and tap debounce. */
class Pill(c: Context, label: String, kind0: Ui.Kind, private val onTap: () -> Unit) : TextView(c) {
    var onRelease: (() -> Unit)? = null
    private var kind = kind0
    private var last = 0L

    init {
        text = label
        gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        textSize = 13f
        isAllCaps = false
        isClickable = true
        minHeight = 0; minimumHeight = 0; minWidth = 0; minimumWidth = 0
        setPadding(Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 10), Ui.dp(c, 10))
        restyle()
        setOnClickListener {
            val now = SystemClock.uptimeMillis()
            if (now - last >= 280) { last = now; onTap() }
        }
    }

    fun setKind(k: Ui.Kind) {
        if (k != kind) { kind = k; restyle() }
    }

    private fun restyle() {
        val r = Ui.dp(context, 12).toFloat()
        val line = Ui.dp(context, 1)
        when (kind) {
            Ui.Kind.PRIMARY -> { background = Ui.gold(r); setTextColor(Ui.ON_ACCENT) }
            Ui.Kind.SECONDARY -> { background = Ui.stroked(Ui.SURFACE_HI, Ui.LINE, r, line); setTextColor(Ui.TEXT) }
            Ui.Kind.DANGER -> { background = Ui.stroked(Ui.BAD_BG, 0x66FF6B6B, r, line); setTextColor(Ui.BAD) }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.94f).scaleY(0.94f).setDuration(80).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animate().scaleX(1f).scaleY(1f).setDuration(140).setInterpolator(DecelerateInterpolator()).start()
                onRelease?.invoke()
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Labelled option tile: glyph on top, short name below, so every option explains itself. */
class Tile(c: Context, glyph: String, label: String, private val onTap: (Tile) -> Unit) : LinearLayout(c) {
    var onRelease: (() -> Unit)? = null
    private val g = TextView(c)
    private val l = TextView(c)
    private var last = 0L

    var active = false
        set(v) { if (field != v) { field = v; restyle() } }
    var danger = false
        set(v) { if (field != v) { field = v; restyle() } }

    init {
        orientation = VERTICAL
        gravity = Gravity.CENTER
        isClickable = true
        g.apply { text = glyph; textSize = 17f; gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
        l.apply { text = label; textSize = 9.5f; gravity = Gravity.CENTER; maxLines = 1; typeface = Typeface.DEFAULT_BOLD }
        addView(g, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT))
        addView(l, LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.WRAP_CONTENT).apply { topMargin = Ui.dp(c, 1) })
        restyle()
        setOnClickListener {
            val now = SystemClock.uptimeMillis()
            if (now - last >= 280) { last = now; onTap(this) }
        }
    }

    fun setGlyph(s: String) { if (g.text.toString() != s) g.text = s }
    fun setLabel(s: String) { if (l.text.toString() != s) l.text = s }

    private fun restyle() {
        val r = Ui.dp(context, 12).toFloat()
        when {
            danger -> {
                background = Ui.stroked(Ui.BAD_BG, 0x66FF6B6B, r, Ui.dp(context, 1))
                g.setTextColor(Ui.BAD); l.setTextColor(Ui.BAD)
            }
            active -> {
                background = Ui.stroked(0xFF241E0E.toInt(), Ui.ACCENT, r, Ui.dp(context, 1))
                g.setTextColor(Ui.ACCENT); l.setTextColor(Ui.TEXT)
            }
            else -> {
                background = Ui.stroked(Ui.SURFACE, Ui.LINE, r, Ui.dp(context, 1))
                g.setTextColor(Ui.TEXT); l.setTextColor(Ui.MUTED)
            }
        }
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                animate().cancel()
                animate().scaleX(0.93f).scaleY(0.93f).setDuration(80).start()
            }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                animate().scaleX(1f).scaleY(1f).setDuration(140).setInterpolator(DecelerateInterpolator()).start()
                onRelease?.invoke()
            }
        }
        return super.onTouchEvent(e)
    }
}

/** Thin neon progress line, 0 to 100 %. The fill eases to each new value instead of jumping. */
class GenBar(c: Context) : View(c) {
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL; color = Ui.SURFACE_HI }
    private val bar = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val glow = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val rect = RectF()
    private var shown = 0f
    private var anim: ValueAnimator? = null

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val sh = LinearGradient(0f, 0f, w.toFloat(), 0f, Ui.RAINBOW, null, Shader.TileMode.CLAMP)
        bar.shader = sh
        glow.shader = sh
    }

    fun setTarget(p: Int) {
        val to = p.coerceIn(0, 100).toFloat()
        if (to == shown && anim == null) return
        anim?.cancel()
        // Going back to 0 is instant; going up eases.
        if (to < shown) { shown = to; anim = null; invalidate(); return }
        anim = ValueAnimator.ofFloat(shown, to).apply {
            duration = 350
            interpolator = DecelerateInterpolator()
            addUpdateListener { shown = it.animatedValue as Float; invalidate() }
            start()
        }
    }

    override fun onDetachedFromWindow() {
        anim?.cancel(); anim = null
        super.onDetachedFromWindow()
    }

    override fun onDraw(canvas: Canvas) {
        val bh = Ui.dp(context, 6).toFloat()
        val cy = height / 2f
        val l = Ui.dp(context, 2).toFloat()
        val r = width - l
        rect.set(l, cy - bh / 2f, r, cy + bh / 2f)
        canvas.drawRoundRect(rect, bh / 2f, bh / 2f, track)
        val w = (r - l) * shown / 100f
        if (w > 0.5f) {
            val alphas = intArrayOf(26, 46, 80)
            for (i in alphas.indices) {
                val grow = Ui.dp(context, 1) * (3 - i) * 1.4f
                rect.set(l - grow * 0.3f, cy - bh / 2f - grow, l + w + grow * 0.3f, cy + bh / 2f + grow)
                glow.alpha = alphas[i]
                canvas.drawRoundRect(rect, bh / 2f + grow, bh / 2f + grow, glow)
            }
            rect.set(l, cy - bh / 2f, l + w, cy + bh / 2f)
            canvas.drawRoundRect(rect, bh / 2f, bh / 2f, bar)
        }
    }
}
