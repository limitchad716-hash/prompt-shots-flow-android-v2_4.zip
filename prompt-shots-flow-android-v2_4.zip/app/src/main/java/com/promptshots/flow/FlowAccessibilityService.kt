package com.promptshots.flow

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.graphics.Rect
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.view.accessibility.AccessibilityWindowInfo

enum class PromptKind { IMAGE, VIDEO, CHATGPT }

/** What the service could read from the Flow screen: image or video mode, and the model chip text. */
data class FlowScreen(val kind: PromptKind?, val model: String?)

class FlowAccessibilityService : AccessibilityService() {
    companion object {
        @Volatile var instance: FlowAccessibilityService? = null
        // Whole-word matches only, so "truncate" or "running..." never counts as "run".
        private val STRONG = Regex("\\b(generate|create|arrow_forward|arrow_upward|send message|send prompt|send|submit)\\b")
        private val WEAK = Regex("\\brun\\b")
        // Real buttons have short labels; long text blocks are never the Generate button.
        private const val MAX_LABEL = 40
        private val VIDEO_HINT = Regex("\\b(veo|text to video|frames to video|ingredients to video)\\b")
        private val IMAGE_HINT = Regex("\\b(nano banana|imagen)\\b")
        private val WORD_VIDEO = Regex("^\\s*videos?\\s*$")
        private val WORD_IMAGE = Regex("^\\s*(images?|photos?)\\s*$")
        // A generating tile shows its progress as text such as "45%".
        private val PERCENT = Regex("(^|\\s)(\\d{1,3})\\s?%(\\s|$)")
        // Buttons next to the prompt box that are never the send arrow.
        private val NOT_SEND = Regex("\\b(add|upload|attach|mic|voice|record|settings|close|clear|delete|remove|cancel|aspect|model|crop|plus|more|menu|expand|collapse|stop)\\b")
        // ChatGPT is busy while its Stop button or an "image is being created" label is on screen.
        private val BUSY = Regex("^\\s*stop( streaming| generating| response)?\\s*$|creating image|image creation")
    }

    override fun onServiceConnected() { instance = this }
    override fun onUnbind(intent: Intent?): Boolean { instance = null; return super.onUnbind(intent) }
    override fun onDestroy() { instance = null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun roots(): List<AccessibilityNodeInfo> {
        val out = mutableListOf<AccessibilityNodeInfo>()
        for (w in windows) {
            if (w.type != AccessibilityWindowInfo.TYPE_APPLICATION) continue
            val r = w.root ?: continue
            if (r.packageName?.toString() != packageName) out.add(r)
        }
        if (out.isEmpty()) rootInActiveWindow?.let { if (it.packageName?.toString() != packageName) out.add(it) }
        return out
    }

    private fun walk(root: AccessibilityNodeInfo, visit: (AccessibilityNodeInfo) -> Boolean): AccessibilityNodeInfo? {
        val q = ArrayDeque<AccessibilityNodeInfo>()
        q.add(root)
        while (q.isNotEmpty()) {
            val n = q.removeFirst()
            if (visit(n)) return n
            for (i in 0 until n.childCount) n.getChild(i)?.let { q.add(it) }
        }
        return null
    }

    private fun findField(): AccessibilityNodeInfo? {
        val rs = roots()
        for (r in rs) walk(r) { it.isEditable && it.isFocused }?.let { return it }
        for (r in rs) walk(r) { it.isEditable && it.isVisibleToUser }?.let { return it }
        return null
    }

    /** True while the prompt box is on screen, i.e. Flow is in front. */
    fun promptBoxVisible(): Boolean = findField() != null

    private fun label(n: AccessibilityNodeInfo) =
        ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).lowercase()

    /** Generate / Create / arrow button found by its text or description. */
    private fun findButton(): AccessibilityNodeInfo? {
        val rs = roots()
        for (re in listOf(STRONG, WEAK)) {
            for (r in rs) walk(r) {
                // Never treat the prompt box itself (its hint says "What do you want to create?") as a button.
                if (!it.isVisibleToUser || !it.isEnabled || it.isEditable) return@walk false
                val l = label(it).trim()
                l.isNotEmpty() && l.length <= MAX_LABEL && re.containsMatchIn(l)
            }?.let { return it }
        }
        return null
    }

    /**
     * Fallback when the arrow has no readable label: the right-most, lowest small button that sits
     * inside the same card as the prompt box (that is where Flow puts the arrow, bottom right).
     */
    private fun findArrowNear(field: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        val dm = resources.displayMetrics
        val maxCard = (dm.density * 280).toInt()
        val maxBtn = (dm.density * 96).toInt()
        var card: AccessibilityNodeInfo = field
        val fr = Rect(); field.getBoundsInScreen(fr)
        var up = field.parent
        var steps = 0
        while (up != null && steps < 5) {
            val r = Rect(); up.getBoundsInScreen(r)
            if (r.height() > maxCard || r.height() > dm.heightPixels / 2) break
            card = up
            up = up.parent
            steps++
        }
        val cr = Rect(); card.getBoundsInScreen(cr)
        var best: AccessibilityNodeInfo? = null
        val br = Rect()
        var bestX = -1
        var bestY = -1
        walk(card) { n ->
            if (n.isVisibleToUser && n.isEnabled && n.isClickable && !n.isEditable) {
                n.getBoundsInScreen(br)
                val l = label(n).trim()
                if (br.width() in 1..maxBtn && br.height() in 1..maxBtn &&
                    br.centerX() > cr.centerX() && br.centerY() >= fr.centerY() &&
                    l.length <= MAX_LABEL && !NOT_SEND.containsMatchIn(l)
                ) {
                    if (br.centerX() > bestX || (br.centerX() == bestX && br.centerY() > bestY)) {
                        bestX = br.centerX(); bestY = br.centerY(); best = n
                    }
                }
            }
            false
        }
        return best
    }

    private fun click(n: AccessibilityNodeInfo): Boolean {
        var x: AccessibilityNodeInfo? = n
        while (x != null && !x.isClickable) x = x.parent
        return x?.performAction(AccessibilityNodeInfo.ACTION_CLICK) ?: false
    }

    /** Real finger tap at a screen point, for buttons that ignore the click action. */
    private fun tapAt(x: Float, y: Float, cb: (Boolean) -> Unit) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        val ok = dispatchGesture(g, object : GestureResultCallback() {
            override fun onCompleted(d: GestureDescription?) { cb(true) }
            override fun onCancelled(d: GestureDescription?) { cb(false) }
        }, null)
        if (!ok) cb(false)
    }

    /** True if the front app is the ChatGPT app, or a page that says "ChatGPT" (browser). */
    private fun isChatGpt(): Boolean {
        for (r in roots()) {
            if (r.packageName?.toString()?.contains("openai.chatgpt") == true) return true
            val hit = walk(r) { n ->
                if (!n.isVisibleToUser) return@walk false
                var t = label(n)
                if (android.os.Build.VERSION.SDK_INT >= 26) t += " " + (n.hintText?.toString() ?: "").lowercase()
                t.length <= 80 && t.contains("chatgpt")
            }
            if (hit != null) return true
        }
        return false
    }

    /** ChatGPT is still answering / creating an image (its Stop button is showing). */
    fun chatGptBusy(): Boolean {
        for (r in roots()) {
            val hit = walk(r) { n ->
                if (!n.isVisibleToUser) return@walk false
                val l = label(n).trim()
                l.isNotEmpty() && l.length <= 40 && BUSY.containsMatchIn(l)
            }
            if (hit != null) return true
        }
        return false
    }

    /**
     * Reads the visible Flow screen and guesses whether it is in image or video mode.
     * Model chips (Nano Banana / Imagen vs Veo) are the strongest signal; plain "Image"/"Video"
     * labels are only used when exactly one of them is visible.
     */
    fun detectScreen(): FlowScreen {
        if (isChatGpt()) return FlowScreen(PromptKind.CHATGPT, "ChatGPT")
        var video: String? = null
        var image: String? = null
        var wordVideo = false
        var wordImage = false
        for (r in roots()) walk(r) { n ->
            if (n.isVisibleToUser && !n.isEditable) {
                val raw = ((n.text?.toString() ?: "") + " " + (n.contentDescription?.toString() ?: "")).trim()
                val l = raw.lowercase()
                if (raw.isNotEmpty() && l.length <= MAX_LABEL) {
                    if (video == null && VIDEO_HINT.containsMatchIn(l)) video = raw
                    else if (image == null && IMAGE_HINT.containsMatchIn(l)) image = raw
                    if (WORD_VIDEO.containsMatchIn(l)) wordVideo = true
                    if (WORD_IMAGE.containsMatchIn(l)) wordImage = true
                }
            }
            false
        }
        return when {
            video != null -> FlowScreen(PromptKind.VIDEO, video)
            image != null -> FlowScreen(PromptKind.IMAGE, image)
            wordVideo && !wordImage -> FlowScreen(PromptKind.VIDEO, null)
            wordImage && !wordVideo -> FlowScreen(PromptKind.IMAGE, null)
            else -> FlowScreen(null, null)
        }
    }

    /** Highest "NN%" text visible on screen (a tile that is still generating), or null if there is none. */
    fun readProgress(): Int? {
        var best: Int? = null
        for (r in roots()) walk(r) { n ->
            if (n.isVisibleToUser) {
                val t = (n.text?.toString() ?: "").trim()
                if (t.isNotEmpty() && t.length <= 8) {
                    val m = PERCENT.find(t)
                    if (m != null) {
                        val v = m.groupValues[2].toIntOrNull()
                        val cur = best
                        if (v != null && v in 0..100 && (cur == null || v > cur)) best = v
                    }
                }
            }
            false
        }
        return best
    }

    /** One try at pressing the send arrow: by its label, then by position, then with a real tap. */
    private fun trySend(cb: (Boolean) -> Unit) {
        val b = findButton()
        if (b != null && click(b)) { cb(true); return }
        val f = findField()
        val arrow = if (f != null) findArrowNear(f) else null
        if (arrow != null) {
            if (click(arrow)) { cb(true); return }
            val r = Rect(); arrow.getBoundsInScreen(r)
            tapAt(r.exactCenterX(), r.exactCenterY(), cb)
            return
        }
        cb(false)
    }

    /**
     * Types the prompt into Flow's prompt box, then presses the arrow button on the right.
     * [done] gets (success, message). success is true only when the arrow was really pressed.
     */
    fun pasteAndRun(text: String, done: (Boolean, String) -> Unit) {
        val field = findField()
        if (field == null) { done(false, "Can't find the prompt box. Open Google Flow first."); return }
        field.performAction(AccessibilityNodeInfo.ACTION_FOCUS)
        val args = Bundle().apply {
            putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        }
        if (!field.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)) {
            done(false, "Couldn't type into the prompt box."); return
        }
        // The arrow only turns on after the text lands, so keep trying for a few seconds.
        val h = Handler(Looper.getMainLooper())
        var tries = 0
        val attempt = object : Runnable {
            override fun run() {
                tries++
                trySend { sent ->
                    if (sent) done(true, "Sent")
                    else if (tries < 8) h.postDelayed(this, 450)
                    else done(false, "Pasted, but can't press the arrow. Tap it yourself.")
                }
            }
        }
        h.postDelayed(attempt, 700)
    }
}
